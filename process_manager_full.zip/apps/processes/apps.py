
from django.apps import AppConfig
class ProcessesConfig(AppConfig):
    name = 'apps.processes'
    verbose_name = 'Processes'
