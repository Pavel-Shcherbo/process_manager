
from django.apps import AppConfig
class CompaniesConfig(AppConfig):
    name = 'apps.companies'
    verbose_name = 'Companies'
