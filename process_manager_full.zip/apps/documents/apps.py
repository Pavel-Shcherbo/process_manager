
from django.apps import AppConfig
class DocumentsConfig(AppConfig):
    name = 'apps.documents'
    verbose_name = 'Documents'
