
from django.apps import AppConfig
class BranchesConfig(AppConfig):
    name = 'apps.branches'
    verbose_name = 'Branches'
