
from django.apps import AppConfig
class CoreConfig(AppConfig):
    name = 'apps.core'
    verbose_name = 'Core'
